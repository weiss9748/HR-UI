//
//  ColVCell.swift
//  HR TAMUK
//
//  Created by Young Lee on 2/10/16.
//  Copyright © 2016 Tamuk. All rights reserved.
//

import UIKit

class ColVCell: UICollectionViewCell {
    
}
