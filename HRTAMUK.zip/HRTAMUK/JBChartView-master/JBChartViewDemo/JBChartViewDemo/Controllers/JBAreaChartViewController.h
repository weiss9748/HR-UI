//
//  JBAreaChartViewController.h
//  JBChartViewDemo
//
//  Created by Lars Ott on 21.04.14.
//  Copyright (c) 2014 Jawbone. All rights reserved.
//

#import "JBBaseChartViewController.h"

@interface JBAreaChartViewController : JBBaseChartViewController

@end
