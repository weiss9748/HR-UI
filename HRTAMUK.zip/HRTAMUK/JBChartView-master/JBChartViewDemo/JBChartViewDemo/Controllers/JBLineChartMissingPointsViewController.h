//
//  JBLineChartMissingPointsViewController.h
//  JBChartViewDemo
//
//  Created by Sebastian Opel on 23.10.14.
//  Copyright (c) 2014 Jawbone. All rights reserved.
//

#import "JBBaseChartViewController.h"

@interface JBLineChartMissingPointsViewController : JBBaseChartViewController

@end
