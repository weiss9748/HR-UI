//
//  contantsTests.h
//  SimpleLineChart
//
//  Created by Bobo on 8/26/15.
//  Copyright (c) 2015 Boris Emorine. All rights reserved.
//

#ifndef SimpleLineChart_contantsTests_h
#define SimpleLineChart_contantsTests_h

static NSInteger numberOfPoints = 100;
static CGFloat pointValue = 3.0;
static NSString * xAxisLabelString = @"X-Axis-Label";
static NSString * popUpPrefix = @"Prefix";
static NSString * popUpSuffix = @"Suffix";

#endif
