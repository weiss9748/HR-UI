//
//  BEMPermanentPopupView.m
//  SimpleLineGraph
//
//  Created by Delisa Mason on 1/29/15.
//  Copyright (c) 2015 Boris Emorine. All rights reserved.
//

#import "BEMPermanentPopupView.h"

@implementation BEMPermanentPopupView

@end

@implementation BEMPermanentPopupLabel

@end
