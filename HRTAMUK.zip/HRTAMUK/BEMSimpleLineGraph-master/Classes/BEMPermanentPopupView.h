//
//  BEMPermanentPopupView.h
//  SimpleLineGraph
//
//  Created by Delisa Mason on 1/29/15.
//  Copyright (c) 2015 Boris Emorine. All rights reserved.
//

@import UIKit;


@interface BEMPermanentPopupView : UIView

@end

@interface BEMPermanentPopupLabel : UILabel

@end
