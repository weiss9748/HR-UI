//
//  TableView.swift
//  HR TAMUK
//
//  Created by Young Lee on 1/22/16.
//  Copyright © 2016 Tamuk. All rights reserved.
//

import Foundation
import UIKit

