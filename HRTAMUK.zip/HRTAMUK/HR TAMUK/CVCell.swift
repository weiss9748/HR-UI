//
//  CVCell.swift
//  HR TAMUK
//
//  Created by Young Lee on 1/25/16.
//  Copyright © 2016 Tamuk. All rights reserved.
//

import UIKit

class CVCell: UICollectionViewCell {
    
    @IBOutlet weak var imgcell: UIImageView!

    @IBOutlet weak var lbcell: UILabel!
}
