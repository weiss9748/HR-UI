//
//  ViewController.swift
//  ChartsTut
//
//  Created by Young Lee on 4/11/16.
//  Copyright © 2016 RaymondScottAyala. All rights reserved.
//

import UIKit
import Darwin
import JBChart

class ViewController: UIViewController, JBLineChartViewDataSource, JBLineChartViewDelegate {

    @IBOutlet weak var lineChart: JBLineChartView!
    @IBOutlet weak var infolabel: UILabel!
    
    
    var chartLegend = [Int](count: 0, repeatedValue: 0)
    var chartData = [Int](count: 0, repeatedValue: 0)
    
    func append (){
    for var i: Int = 0; i < 50; i+=1{
    var mock = Int(arc4random_uniform(250) + 1)
    chartData.append(mock)
        }
    for var j: Int = 1; j < 51; j+=1{
        chartLegend.append(j)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor = UIColor.darkGrayColor()
        self.append()
        //line chart setup
        lineChart.backgroundColor = UIColor.darkGrayColor()
        lineChart.delegate = self
        lineChart.dataSource = self
        lineChart.minimumValue = 0
        lineChart.maximumValue = 300
        
        lineChart.reloadData()
        lineChart.setState(.Collapsed, animated: true)
        
    }
    
        
    

override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    
    let footerView = UIView(frame: CGRectMake(0, 0, lineChart.frame.width, 50))
    
    print("viewDidLoad: \(lineChart.frame.width)")
    
    let footer1 = UILabel(frame: CGRectMake(0, 0, lineChart.frame.width/2 - 8, 16))
    footer1.textColor = UIColor.whiteColor()
    footer1.text = "Seconds"
    footer1.textAlignment = NSTextAlignment.Center
    
    let footer2 = UILabel(frame: CGRectMake(lineChart.frame.width/2 - 8, 0, lineChart.frame.width/2 - 8, 16))
    footer2.textColor = UIColor.whiteColor()
    footer2.text = "\(chartLegend[chartLegend.count - 1])"
    footer2.textAlignment = NSTextAlignment.Center
    
    footerView.addSubview(footer1)
    footerView.addSubview(footer2)
    
    let header = UILabel(frame: CGRectMake(0, 0, lineChart.frame.width, 50))
    header.textColor = UIColor.whiteColor()
    header.font = UIFont.systemFontOfSize(24)
    header.text = "Heart Rate in BPM"
    header.textAlignment = NSTextAlignment.Center
    
    lineChart.footerView = footerView
    lineChart.headerView = header
    
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        lineChart.reloadData()
        var timer = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: Selector("showChart"), userInfo: nil, repeats: false)
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        hideChart()
    }
    
    func hideChart() {
        lineChart.setState(.Collapsed, animated: true)
    }
    
    func showChart() {
        lineChart.setState(.Expanded, animated: true)
    }
    
    //JBLineChartView
    
    func numberOfLinesInLineChartView(lineChartView: JBLineChartView!) -> UInt {
        return 1
    }
    

    
    func lineChartView(lineChartView: JBLineChartView!, numberOfVerticalValuesAtLineIndex lineIndex: UInt) -> UInt {
        if (lineIndex == 0) {
            return UInt(chartData.count)
        }
        return 0
    }
    func lineChartView(lineChartView: JBLineChartView!, verticalValueForHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> CGFloat {
        if (lineIndex == 0) {
            return CGFloat(chartData[Int(horizontalIndex)])
        }
        return 0
    }
    func lineChartView(lineChartView: JBLineChartView!, colorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        if (lineIndex == 0) {
            return UIColor.lightGrayColor()
        }
        return UIColor.whiteColor()
    }
    func lineChartView(lineChartView: JBLineChartView!, showsDotsForLineAtLineIndex lineIndex: UInt) -> Bool {
        return true
    }
    
    func lineChartView(lineChartView: JBLineChartView!, colorForDotAtHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> UIColor! {
        return UIColor.lightGrayColor()
    }
    
    func lineChartView(lineChartView: JBLineChartView!, smoothLineAtLineIndex lineIndex: UInt) -> Bool {
        return true
    }
    
    func lineChartView(lineChartView: JBLineChartView!, didSelectLineAtIndex lineIndex: UInt, horizontalIndex: UInt, touchPoint: CGPoint) {
        if (lineIndex == 0) {
            let data = chartData[Int(horizontalIndex)]
            let key = chartLegend[Int(horizontalIndex)]
            infolabel.text = "BPM is \(data) at  \(key) seconds"
        }
    }
    
    func didDeselectLineInLineChartView(lineChartView: JBLineChartView!) {
        infolabel.text = ""
    }


}